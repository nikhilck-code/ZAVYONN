/* Add verified products here. Never publish sample or unverified inventory.
   Each product: {id, category, name, price, description, details, images, available, variants, featured, newArrival}
   Category values: home-decor | fashion-accessories | garments | others
   Images should be optimized, appropriately licensed assets. */
window.ZAVYON_PRODUCTS = [];
window.ZAVYON_SETTINGS = {
  whatsapp: '916282047605',
  instagramUrl: 'https://www.instagram.com/nikhi.eey/',
  email: '',        // Add the business email when supplied.
  address: ''       // Optional verified business address.
};
