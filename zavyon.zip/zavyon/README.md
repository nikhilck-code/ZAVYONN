# ZAVYON website

A lightweight static website built with plain HTML, CSS, and JavaScript. It includes a Vercel rewrite config for safe static serving and a branded SVG favicon. It has no backend or admin dashboard. The product catalogue and contact settings are editable in `catalog.js`. Saved finds persist in the visitor’s browser; no account or database is used.

## Add verified products

Append product objects to `window.ZAVYON_PRODUCTS` in `catalog.js` using this shape:

```js
{
  id: 'distinct-product-id',
  category: 'home-decor', // home-decor | fashion-accessories | garments | others
  name: 'Verified product name',
  price: 3200, // actual INR price as a number
  description: 'Short factual product description.',
  details: 'Optional specifications or materials.',
  images: ['https://your-image-url.example/product.jpg'],
  available: true,
  variants: { Colour: ['Ivory', 'Charcoal'], Size: ['S', 'M', 'L'] },
  featured: false,
  newArrival: false
}
```

Only list real products, actual selling prices, available variations, and images you have rights to use. Set `available: false` to show the item without enabling WhatsApp ordering. Product detail routes use the product `id`. Collection pages include search, sorting, availability filtering, save-for-later, and direct WhatsApp enquiry. Product pages support variant selection, quantity, browser share, and WhatsApp ordering.

## Configure brand contact details

In `catalog.js`, keep the WhatsApp number as `916282047605`. The Instagram URL is set to the profile you supplied. Add the business email when supplied. Address is optional.

## Run locally

Open `index.html` in a modern browser. For static hosting, publish the entire `zavyon` folder with its file paths intact. A web server is recommended for consistent browser behavior.

WhatsApp opens an enquiry containing the selected product, price, quantity, selected variants, and current product URL. It does not claim that an order or payment is complete; ZAVYON confirms the details with the customer.


## Deploy to Vercel

The folder is ready to import as a static site. If your Git repository root is this `zavyon` folder, keep the Vercel project root at `.`. If the repository root is the containing workspace, set Vercel’s Root Directory to `outputs/zavyon`. No build command or framework preset is needed; serve the project files as-is. `vercel.json` routes requests to `index.html`, matching Vercel’s documented SPA fallback pattern.
