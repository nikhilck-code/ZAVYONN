import { WHATSAPP_DESTINATION } from './config'

export function formatPrice(price) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(price)
}

export function whatsappUrl(product, quantity = 1, selected = {}) {
  const selectedOptions = Object.entries(selected)
    .filter(([, value]) => value)
    .map(([key, value]) => `${key}: ${value}`)
    .join(', ') || 'Not applicable'

  const message = [
    'Hello ZAVYON, I would like to enquire about this product.',
    '',
    `Product: ${product.name}`,
    `Category: ${product.category.replaceAll('-', ' ')}`,
    `Price: ${formatPrice(product.price)}`,
    `Quantity: ${quantity}`,
    `Selected options: ${selectedOptions}`,
    `Product link: ${window.location.origin}/product/${product.slug}`,
    '',
    'Please confirm availability, delivery charges, and payment details.',
    'Thank you.',
  ].join('\n')

  return `https://wa.me/${WHATSAPP_DESTINATION}?text=${encodeURIComponent(message)}`
}
