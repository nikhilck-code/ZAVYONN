import React from 'react'
import { Link } from 'react-router-dom'
import { MessageCircle, ArrowUpRight } from 'lucide-react'
import { INSTAGRAM_URL } from '../config'
import { whatsappUrl } from '../utils'

export default function Footer() {
  const contactUrl = `https://wa.me/916282047605?text=${encodeURIComponent('Hello ZAVYON, I have a question.')}`
  return (
    <footer id="contact" className="site-footer">
      <div className="footer-top">
        <div>
          <Link to="/" className="footer-wordmark">ZAVYON<span>®</span></Link>
          <p className="footer-note">A curated world of considered finds.</p>
        </div>
        <div className="footer-links">
          <div><span className="eyebrow">EXPLORE</span><Link to="/shop">Shop all</Link><Link to="/category/home-decor">Home Decor</Link><Link to="/category/fashion-accessories">Fashion Accessories</Link><Link to="/category/garments">Garments</Link><Link to="/category/others">Others</Link></div>
          <div><span className="eyebrow">CONNECT</span><a href={contactUrl} target="_blank" rel="noreferrer">WhatsApp enquiries <ArrowUpRight size={13}/></a>{INSTAGRAM_URL ? <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer">Instagram <ArrowUpRight size={13}/></a> : <span className="footer-muted">Instagram profile coming soon</span>}<Link to="/about">Our story</Link></div>
          <div><span className="eyebrow">INFORMATION</span><Link to="/policy">Store policies</Link><span className="footer-muted">Prices and availability are confirmed directly before an order is accepted.</span></div>
        </div>
      </div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} ZAVYON</span><span>THE ART OF DISCOVERY</span><a href={contactUrl} target="_blank" rel="noreferrer" aria-label="Contact ZAVYON through WhatsApp"><MessageCircle size={16}/></a></div>
    </footer>
  )
}
