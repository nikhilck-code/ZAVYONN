import React from 'react'
import { Link } from 'react-router-dom'
import { ArrowUpRight } from 'lucide-react'
import { categories } from '../data/products'
import { formatPrice } from '../utils'

export default function ProductCard({ product }) {
  const category = categories.find(c => c.slug === product.category)
  return (
    <article className="product-card">
      <Link to={`/product/${product.slug}`} className="product-image-link">
        <div className="product-image-wrap">
          <img src={product.image} alt={product.name} loading="lazy"/>
          {product.demo && <span className="demo-label">SAMPLE PRODUCT</span>}
          {!product.available && <span className="sold-label">Currently unavailable</span>}
          <span className="product-image-arrow"><ArrowUpRight size={17}/></span>
        </div>
      </Link>
      <div className="product-meta"><span>{category?.name || 'Collection'}</span><span>{formatPrice(product.price)}</span></div>
      <Link to={`/product/${product.slug}`} className="product-name">{product.name}</Link>
    </article>
  )
}
