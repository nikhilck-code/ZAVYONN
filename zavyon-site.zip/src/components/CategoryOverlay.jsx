import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { X, ArrowUpRight } from 'lucide-react'
import { categories } from '../data/products'

export default function CategoryOverlay({ open, onClose }) {
  useEffect(() => {
    if (!open) return
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const onKey = e => { if (e.key === 'Escape') onClose() }
    window.addEventListener('keydown', onKey)
    return () => {
      document.body.style.overflow = previous
      window.removeEventListener('keydown', onKey)
    }
  }, [open, onClose])

  if (!open) return null

  const choose = () => {
    try { sessionStorage.setItem('zavyon-category-intro-seen', '1') } catch {}
    onClose()
  }

  return (
    <div className="entrance-backdrop" role="dialog" aria-modal="true" aria-label="Choose a ZAVYON collection">
      <div className="entrance-panel">
        <div className="entrance-topline"><span className="entrance-wordmark">ZAVYON<span>®</span></span><button className="entrance-close" onClick={choose} aria-label="Close category selection"><X size={19}/></button></div>
        <div className="entrance-intro">
          <span className="eyebrow">WELCOME TO ZAVYON</span>
          <h1>Find your kind<br/>of <em>extraordinary.</em></h1>
          <p>Four distinct worlds. One considered collection.</p>
        </div>
        <div className="entrance-grid">
          {categories.map(cat => (
            <Link key={cat.slug} to={`/category/${cat.slug}`} className="entrance-tile" onClick={choose} style={{'--tile-image': `url("${cat.image}")`}}>
              <span className="tile-number">{cat.number}</span>
              <span className="tile-copy"><span className="tile-title">{cat.name}</span><span className="tile-tagline">{cat.tagline}</span></span>
              <span className="tile-arrow"><ArrowUpRight size={17}/></span>
            </Link>
          ))}
        </div>
        <div className="entrance-bottom"><span>CURATED TO BE DISCOVERED</span><Link to="/shop" onClick={choose}>Explore everything <ArrowUpRight size={13}/></Link></div>
      </div>
    </div>
  )
}
