import React, { useState } from 'react'
import { Link, NavLink } from 'react-router-dom'
import { Menu, X, ArrowUpRight } from 'lucide-react'
import { INSTAGRAM_URL } from '../config'

export default function Header({ onOpenCategories }) {
  const [open, setOpen] = useState(false)
  const close = () => setOpen(false)

  return (
    <header className="site-header">
      <Link className="wordmark" to="/" onClick={close} aria-label="ZAVYON home">ZAVYON<span>®</span></Link>
      <nav className={`main-nav ${open ? 'is-open' : ''}`}>
        <NavLink to="/shop" onClick={close}>Shop all</NavLink>
        <button className="nav-text-button" onClick={() => { onOpenCategories(); close() }}>Collections</button>
        <Link to="/about" onClick={close}>Our story</Link>
        <a href="#contact" onClick={close}>Contact</a>
        {INSTAGRAM_URL && <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" onClick={close}>Instagram <ArrowUpRight size={13}/></a>}
      </nav>
      <div className="header-actions">
        <button className="text-link desktop-collection" onClick={onOpenCategories}>Choose your world <span>↗</span></button>
        <button className="menu-toggle" onClick={() => setOpen(!open)} aria-label={open ? 'Close menu' : 'Open menu'}>
          {open ? <X size={22}/> : <Menu size={22}/>}
        </button>
      </div>
    </header>
  )
}
