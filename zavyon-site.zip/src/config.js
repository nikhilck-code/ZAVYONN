// Keep the destination in one place. It is used only for clickable WhatsApp links.
// It is not rendered as visible phone-number text anywhere in the website.
export const WHATSAPP_DESTINATION = '916282047605'

// Replace with your real Instagram profile URL before launch.
export const INSTAGRAM_URL = ''
export const BRAND_NAME = 'ZAVYON'
