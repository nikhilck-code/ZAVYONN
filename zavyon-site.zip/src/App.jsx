import React, { useCallback, useEffect, useState } from 'react'
import { Link, Navigate, Route, Routes, useParams, useSearchParams } from 'react-router-dom'
import { ArrowDownRight, ArrowRight, ArrowUpRight, MessageCircle, SlidersHorizontal } from 'lucide-react'
import Header from './components/Header'
import Footer from './components/Footer'
import CategoryOverlay from './components/CategoryOverlay'
import ProductCard from './components/ProductCard'
import { categories, products } from './data/products'
import { formatPrice, whatsappUrl } from './utils'

function useIntro() {
  const [open, setOpen] = useState(false)
  useEffect(() => {
    let seen = false
    try { seen = sessionStorage.getItem('zavyon-category-intro-seen') === '1' } catch {}
    if (!seen) setOpen(true)
  }, [])
  const close = useCallback(() => {
    try { sessionStorage.setItem('zavyon-category-intro-seen', '1') } catch {}
    setOpen(false)
  }, [])
  const reopen = useCallback(() => setOpen(true), [])
  return { open, close, reopen }
}

function Home({ onOpenCategories }) {
  const featured = products.filter(p => p.featured && p.available)
  return <>
    <section className="home-hero">
      <div className="hero-photo" role="img" aria-label="Warm editorial interior with considered objects"/>
      <div className="hero-shade"/>
      <div className="hero-content">
        <span className="eyebrow light-eyebrow">THE ART OF DISCOVERY</span>
        <h1>Considered finds.<br/><em>Distinctive living.</em></h1>
        <p>A curated world of home, style, and everyday discoveries.</p>
        <Link to="/shop" className="button button-light">Discover the collection <ArrowUpRight size={16}/></Link>
      </div>
      <span className="hero-index">COLLECTION 001 — EVERYDAY OBJECTS</span>
      <a className="hero-scroll" href="#collections"><span>SCROLL TO DISCOVER</span><ArrowDownRight size={16}/></a>
    </section>
    <section className="intro-strip">
      <span className="eyebrow">A NOTE ON DISCOVERY</span>
      <p>Not just things to own.<br/><em>Finds to make your own.</em></p>
      <span className="intro-mark">Z.</span>
    </section>
    <section id="collections" className="section collections-section">
      <div className="section-heading"><div><span className="eyebrow">FOUR WAYS TO DISCOVER</span><h2>A collection beyond<br/><em>categories.</em></h2></div><button className="text-link" onClick={onOpenCategories}>Choose your world <ArrowUpRight size={15}/></button></div>
      <div className="collection-editorial">
        <Link to="/category/home-decor" className="collection-feature collection-home">
          <img src={categories[0].image} alt="Home decor collection" loading="lazy"/>
          <span className="collection-num">01 / HOME</span><span className="collection-label"><strong>Home Decor</strong><span>Elevate your space <ArrowUpRight size={16}/></span></span>
        </Link>
        <div className="collection-side">
          {categories.slice(1).map((cat, i) => <Link to={`/category/${cat.slug}`} className={`collection-small collection-small-${i}`} key={cat.slug}>
            <img src={cat.image} alt={`${cat.name} collection`} loading="lazy"/>
            <span className="collection-num">{cat.number} / COLLECTION</span><span className="collection-label"><strong>{cat.name}</strong><span>{cat.tagline} <ArrowUpRight size={15}/></span></span>
          </Link>)}
        </div>
      </div>
    </section>
    {featured.length > 0 && <section className="section featured-section">
      <div className="section-heading"><div><span className="eyebrow">SELECTED FOR YOU</span><h2>Objects of <em>interest.</em></h2></div><Link to="/shop" className="text-link">Shop all products <ArrowUpRight size={15}/></Link></div>
      <div className="product-grid">{featured.slice(0,4).map(p => <ProductCard key={p.id} product={p}/>)}</div>
    </section>}
    <section className="story-band">
      <div className="story-image"><img src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1400&q=85" alt="Calm contemporary interior" loading="lazy"/></div>
      <div className="story-copy"><span className="eyebrow">A LITTLE ABOUT US</span><h2>Less ordinary.<br/><em>More considered.</em></h2><p>ZAVYON brings together selected finds for the spaces we live in, the styles we express, and the details that make everyday life our own.</p><Link to="/about" className="button button-dark">Discover our story <ArrowUpRight size={16}/></Link></div>
    </section>
    <section className="closing-cta"><span className="eyebrow">YOUR NEXT FIND AWAITS</span><h2>Your next favourite find<br/>might be <em>here.</em></h2><Link to="/shop" className="button button-dark">Explore ZAVYON <ArrowRight size={16}/></Link></section>
  </>
}

function Shop({ categorySlug }) {
  const [sort, setSort] = useState('featured')
  const [query, setQuery] = useState('')
  const category = categories.find(c => c.slug === categorySlug)
  let list = products.filter(p => (!categorySlug || p.category === categorySlug) && p.name.toLowerCase().includes(query.toLowerCase()))
  if (sort === 'low') list = [...list].sort((a,b) => a.price-b.price)
  if (sort === 'high') list = [...list].sort((a,b) => b.price-a.price)
  if (sort === 'featured') list = [...list].sort((a,b) => Number(b.featured)-Number(a.featured))
  return <main className="page-shell">
    <div className="collection-page-hero" style={category ? {'--page-image': `url("${category.image}")`} : {}}>
      <span className="eyebrow light-eyebrow">{category ? `COLLECTION ${category.number}` : 'THE ZAVYON EDIT'}</span>
      <h1>{category ? category.name : 'Shop all'}<em>{category ? ` — ${category.tagline}` : ' / Discover more.'}</em></h1>
      <p>{category ? category.description : 'Explore the complete collection of considered finds across every ZAVYON category.'}</p>
    </div>
    <div className="shop-toolbar"><span>{list.length} {list.length === 1 ? 'product' : 'products'}{category ? ` in ${category.name}` : ''}</span><div className="shop-controls"><label className="search-control"><span className="sr-only">Search products</span><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Find a product"/></label><label className="sort-control"><SlidersHorizontal size={15}/><span className="sr-only">Sort products</span><select value={sort} onChange={e => setSort(e.target.value)}><option value="featured">Featured</option><option value="low">Price: low to high</option><option value="high">Price: high to low</option></select></label></div></div>
    <div className="product-grid shop-grid">{list.map(p => <ProductCard key={p.id} product={p}/>)}</div>
    {list.length === 0 && <div className="empty-state"><span className="eyebrow">NOT FOUND</span><h2>No finds just yet.</h2><p>Try another search, or explore a different collection.</p><Link to="/shop" className="button button-dark">View all products</Link></div>}
    {products.some(p => p.demo) && <p className="demo-notice">Sample catalogue shown for design preview. Replace demo items with real products before publishing.</p>}
  </main>
}

function ProductDetail() {
  const { slug } = useParams()
  const product = products.find(p => p.slug === slug)
  const [quantity, setQuantity] = useState(1)
  const [selected, setSelected] = useState({})
  if (!product) return <main className="empty-state page-shell"><h1>Product not found</h1><Link to="/shop" className="button button-dark">Back to shop</Link></main>
  const missing = product.variants.some(v => !selected[v.name])
  return <main className="product-detail page-shell">
    <div className="breadcrumbs"><Link to="/">Home</Link><span>/</span><Link to={`/category/${product.category}`}>{categories.find(c => c.slug === product.category)?.name}</Link><span>/</span><span>{product.name}</span></div>
    <div className="detail-layout">
      <div className="detail-image"><img src={product.image} alt={product.name}/>{product.demo && <span className="demo-label">SAMPLE PRODUCT</span>}</div>
      <div className="detail-info"><span className="eyebrow">{categories.find(c => c.slug === product.category)?.name}</span><h1>{product.name}</h1><div className="detail-price">{formatPrice(product.price)}</div><p className="detail-description">{product.description}</p>
        {product.demo && <p className="sample-warning">This is a sample listing. Replace it with accurate product information before accepting orders.</p>}
        <div className="detail-options">{product.variants.map(variant => <fieldset className="variant-field" key={variant.name}><legend>{variant.name}</legend><div className="variant-options">{variant.options.map(option => <button type="button" key={option} className={`variant-option ${selected[variant.name] === option ? 'selected' : ''}`} onClick={() => setSelected(s => ({...s, [variant.name]: option}))}>{option}</button>)}</div></fieldset>)}</div>
        <div className="quantity-row"><span>Quantity</span><div className="quantity-stepper"><button onClick={() => setQuantity(q => Math.max(1,q-1))} aria-label="Decrease quantity">−</button><span>{quantity}</span><button onClick={() => setQuantity(q => Math.min(20,q+1))} aria-label="Increase quantity">+</button></div></div>
        <a className={`button button-dark buy-button ${(!product.available || missing) ? 'disabled' : ''}`} href={product.available && !missing ? whatsappUrl(product, quantity, selected) : undefined} target="_blank" rel="noreferrer" onClick={e => { if (!product.available || missing) e.preventDefault() }}>{!product.available ? 'Currently unavailable' : missing ? 'Choose options to continue' : <>Enquire via WhatsApp <ArrowUpRight size={16}/></>}</a>
        <p className="order-note">Your order enquiry opens in WhatsApp. Availability, delivery charges, and payment are confirmed directly before an order is accepted.</p>
        <div className="product-specs"><span className="eyebrow">DETAILS</span>{product.details.map((d,i) => <p key={i}>{d}</p>)}</div>
      </div>
    </div>
  </main>
}

function About() {
  return <main className="page-shell about-page"><span className="eyebrow">THE ZAVYON STORY</span><h1>Less ordinary.<br/><em>More considered.</em></h1><div className="about-grid"><img src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&w=1400&q=85" alt="Thoughtful interior styling"/><div><p>ZAVYON is a curated destination for discovering products across the spaces we live in, the styles we express, and the details that make everyday life our own.</p><p>Our collections bring together home decor, fashion accessories, garments, and other discoveries under one considered identity.</p><Link to="/shop" className="button button-dark">Explore the collection <ArrowUpRight size={16}/></Link></div></div></main>
}

function Policy() {
  return <main className="page-shell policy-page"><span className="eyebrow">IMPORTANT INFORMATION</span><h1>Store <em>policies.</em></h1><p>This starter page must be completed with ZAVYON's actual business policies before launch.</p><h2>Orders and availability</h2><p>Product availability, final pricing, delivery charges, and order acceptance should be confirmed directly with ZAVYON before payment.</p><h2>Shipping, cancellation and returns</h2><p>Add your actual shipping timelines, delivery areas, cancellation terms, return eligibility, and refund process here. Do not publish policies until they accurately reflect how the business operates.</p><h2>Privacy</h2><p>Describe what customer information is collected, why it is used, how it is handled, and how customers can contact the business with privacy questions.</p></main>
}

function NotFound() {
  return <main className="empty-state page-shell"><span className="eyebrow">404 — PAGE NOT FOUND</span><h1>This path ends here.</h1><Link to="/" className="button button-dark">Return to ZAVYON</Link></main>
}

export default function App() {
  const { open, close, reopen } = useIntro()
  return <div className="app"><Header onOpenCategories={reopen}/><Routes>
    <Route path="/" element={<Home onOpenCategories={reopen}/>}/>
    <Route path="/shop" element={<Shop/>}/>
    <Route path="/category/:slug" element={<CategoryRoute/>}/>
    <Route path="/product/:slug" element={<ProductDetail/>}/>
    <Route path="/about" element={<About/>}/>
    <Route path="/policy" element={<Policy/>}/>
    <Route path="*" element={<NotFound/>}/>
  </Routes><Footer/><CategoryOverlay open={open} onClose={close}/></div>
}

function CategoryRoute() {
  const { slug } = useParams()
  if (!categories.some(c => c.slug === slug)) return <NotFound/>
  return <Shop categorySlug={slug}/>
}
