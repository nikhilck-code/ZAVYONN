# ZAVYON storefront

A premium editorial-style React + Vite storefront with:
- First-visit category selection overlay
- Four category routes
- Shop all, search, sorting
- Product detail pages and variants
- WhatsApp product enquiry links
- Responsive layouts
- Static product catalogue for easy editing
- Cloudflare Pages / Vercel-compatible build

## Before launch

1. Edit `src/data/products.js`. Replace all demo items, prices, descriptions, images, and specifications with accurate information. Sample items are explicitly marked as demos.
2. Check `src/config.js`. The WhatsApp destination is configured there and is only used for clickable links; the phone number is not rendered as visible page text.
3. Set `INSTAGRAM_URL` in `src/config.js` to the actual profile URL.
4. Complete the policy page in `src/App.jsx` so it matches your actual business practices.
5. Replace sample images with your actual product photos and confirm you have permission to use all images.
6. Test every product, variant, WhatsApp link, and page on mobile and desktop.

## Run locally

Requires Node.js 18 or newer.

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

The build output is in `dist/`.

## Deploy to Vercel

Import this project/repository into Vercel. Framework preset: Vite. Build command: `npm run build`. Output directory: `dist`.

## Deploy to Cloudflare Pages

Connect the repository to Cloudflare Pages. Build command: `npm run build`. Build output directory: `dist`.

## Notes

- This is a static storefront. It does not include payment processing, order storage, customer accounts, or an admin dashboard.
- Orders are enquiries sent to WhatsApp. The business must confirm availability, delivery, and payment directly.
- Browser-based WhatsApp links necessarily contain the destination in the hyperlink URL, but the number is not displayed as visible website text.
- The sample catalogue must be replaced before accepting real orders.
